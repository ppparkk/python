#계산기 기능
#def : 정의하다. 뒤에 함수를 만들 수 있음

def plus() :
    print('더하기 기능 처리')
    #두 수를 입력 받아서 더하기 처리
    data1 = int(input("수를 입력하세요"))
    data2 = int(input("수를 입력하세요"))
    print(data1+data2)

def minus() :
    print('빼기 기능 처리')
    # 두 수를 입력 받아서 빼기 처리
    data3 = int(input("수를 입력하세요"))
    data4 = int(input("수를 입력하세요"))
    print(data3 - data4)

def mul() :
    print('곱하기 기능처리')
    d1 = int(input("숫자입력"))
    d2 = int(input("숫자입력"))
    print(d1*d2)