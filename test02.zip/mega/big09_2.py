# 영어점수 입력 : 76
# 수학점수 입력 : 80
# 국어점수 입력 : 60
# -----------------------
# 세 과목의 합은 216
# 세 과목의 평균은 72점

data1 = input("영어점수 입력")
data2 = input("수학점수 입력")
data3 = input("국어점수 입력")
print("-----------------------")

data4 = int(data1)
data5 = int(data2)
data6 = int(data3)

sum = data4+data5+data6
ave = sum/3

print("세 과목의 합은" , sum)
print("세 과목의 평균은" , ave)