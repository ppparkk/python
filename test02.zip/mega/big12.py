#계산기 모듈을 여기에 쓰겠다고 표현
from other import out

out.plus()
out.minus()
out.mul()