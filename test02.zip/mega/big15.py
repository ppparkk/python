# while True:
#     print('한시간 남았어요')

# 주석처리 CTRL+/

# a = 10
# while a > 0 :
#     print(a)   #무한루프
#     a=a-1

# b=0
# 1. 0부터 99까지 찍어보세요
# 2. 1부터 100까지 찍어보세요.
# 3. 1부터 100까지 짝수만 찍어보세요.

# while b < 100 :
#     print(b, end =' ')
#     b=b+1

# while b < 100 :
#     print(b+1)
#     b=b+1

# b=0
# while b < 100 :
#     if( b % 2 == 0) :
#         print(b)
#     b=b+1

# # 4. 0~99 중 3의 배수를 찍어보세요
# while b < 100 :
#     if( b % 3 == 0) :
#         print(b)
#     b=b+1

# # 5. 0~99 중 5의 배수의 개수 구해보세요 (망한버전)
# start = 0
# while start < 100 :
#     if ( start % 5 == 0) :
#         print(start)
#     start=start+1
#풀이과정

start = 1
count = 0
while start < 100 :
    if ( start % 5 == 0) :
        count = count + 1
    start=start+1
print('5의 배수는', count, '개')

start = 1
count = 0
while start < 100 :
    if ( start % 5 == 0) :
        count = count + 1
    start=start+1
print(count)

# c=0
# # 6. 안녕히가세요 5번 프린트
# while c < 5 :
#     print('안녕히가세요') #무한루프
#     c = c+1  #무한루프 하지 않게 조건, 증감식

