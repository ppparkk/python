from tkinter import messagebox

def info() :
    d1 = input("같이 볼 사람이름")
    d2 = input('관계')
    messagebox.showinfo("확인", d1 + " " + d2)

def pay() :
    d3 = input('인원 수 입력')
    print("지불금액은",int(d3)*10000,'입니다.')
